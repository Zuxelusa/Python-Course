from ui.ui_controller import main

main()