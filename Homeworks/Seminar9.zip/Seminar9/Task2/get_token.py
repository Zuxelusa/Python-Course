def get_telegram_token():
    file = "D:\!MyEducation\\tbid.txt"
    with open(file, "r") as f:
          return f.readline()
